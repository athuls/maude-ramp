package edu.berkeley.kaiju.frontend.response;

public class ClientPutAllResponse extends ClientResponse {
}
