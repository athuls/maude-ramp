package edu.berkeley.kaiju.frontend.request;

public abstract class ClientRequest {
}
