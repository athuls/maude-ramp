package edu.berkeley.kaiju.frontend.response;

public abstract class ClientResponse {
}
