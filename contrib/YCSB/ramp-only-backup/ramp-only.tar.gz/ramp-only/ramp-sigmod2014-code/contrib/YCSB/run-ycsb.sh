bin/ycsb run kaiju -p hosts=155.98.38.116 -p port=8080 -P workloads/workloada -p operationcount=100000 -p maxexecutiontime=30 -p isolation_level=READ_ATOMIC -p read_atomic_algorithm=KEY_LIST -s
